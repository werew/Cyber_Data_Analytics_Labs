Instructions:
# pip install jupyter
- Run csv2dataframe.ipynb to create the dataframe
- Run analysis.ipynb to do the learning
